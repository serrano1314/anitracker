"use strict";
(() => {
  // src/parsers/generic.ts
  var EPISODE_PATTERNS = [
    /episode\s*(\d+)/i,
    /\bep\.?\s*(\d+)/i,
    /\be(\d+)\b/i,
    /-\s*(\d+)\s*$/
  ];
  function parseEpisode(text) {
    for (const pattern of EPISODE_PATTERNS) {
      const match = pattern.exec(text);
      if (!match?.[1]) {
        continue;
      }
      const episode = Number.parseInt(match[1], 10);
      if (episode >= 1) {
        return episode;
      }
    }
    return null;
  }
  function looksLikeMovie(text) {
    return /\b(?:movie|film)\b/i.test(text);
  }
  function siteHost(pageUrl) {
    const hostname = new URL(pageUrl).hostname.replace(/^www\./i, "");
    return hostname;
  }
  function readTitleAndEpisode(input) {
    const rawTitle = input.title.trim() || input.heading.trim();
    const episode = parseEpisode([input.heading, input.title, input.pageUrl].filter(Boolean).join("\n"));
    const isMovie = episode === null && looksLikeMovie(`${input.title}
${input.heading}
${input.pageUrl}`);
    return {
      rawTitle,
      episode: episode ?? (isMovie ? 1 : null),
      isMovie
    };
  }

  // src/queue.ts
  function progressKey(event) {
    return `${event.siteHost}|${event.rawTitle}|${event.episode}|${event.isMovie}`;
  }
  function claimEpisode(sent2, event) {
    if (!event) {
      return null;
    }
    const key = progressKey(event);
    if (sent2.has(key)) {
      return null;
    }
    sent2.add(key);
    return event;
  }

  // src/content.ts
  var WATCH_THRESHOLD = 0.85;
  var sent = /* @__PURE__ */ new Set();
  var watchedVideos = /* @__PURE__ */ new WeakSet();
  if (!window.__animeTrackerInjected) {
    window.__animeTrackerInjected = true;
    watchHistory();
    watchTitle();
    watchVideos();
    scheduleSave();
    window.setInterval(saveCurrent, 1500);
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      if (isRecord(message) && message.type === "read-page") {
        sendResponse({ event: currentEvent() });
        return true;
      }
      if (isRecord(message) && message.type === "show-toast" && typeof message.text === "string") {
        showToast(message.text);
      }
      return void 0;
    });
  }
  function currentEvent() {
    const heading = document.querySelector("h1")?.textContent?.trim() ?? "";
    const parsed = readTitleAndEpisode({
      title: document.title,
      heading,
      pageUrl: location.href
    });
    if (!parsed.rawTitle || parsed.episode === null) {
      return null;
    }
    return {
      rawTitle: parsed.rawTitle.slice(0, 500),
      episode: parsed.episode,
      siteHost: siteHost(location.href),
      pageUrl: location.href.slice(0, 2e3),
      isMovie: parsed.isMovie
    };
  }
  function watchVideos() {
    for (const video of document.querySelectorAll("video")) {
      if (watchedVideos.has(video)) {
        continue;
      }
      watchedVideos.add(video);
      const report = () => {
        considerProgress(video);
      };
      video.addEventListener("timeupdate", report);
      video.addEventListener("ended", report);
    }
  }
  function considerProgress(video) {
    const duration = video.duration;
    const ended = video.ended;
    const farEnough = Number.isFinite(duration) && duration > 0 && video.currentTime / duration >= WATCH_THRESHOLD;
    if (!ended && !farEnough) {
      return;
    }
    saveCurrent();
  }
  var saveTimer;
  function scheduleSave() {
    window.clearTimeout(saveTimer);
    saveTimer = window.setTimeout(() => {
      saveCurrent();
    }, 400);
  }
  function saveCurrent() {
    const event = claimEpisode(sent, currentEvent());
    if (!event) {
      return;
    }
    void chrome.runtime.sendMessage({ type: "save-progress", event });
  }
  function watchTitle() {
    const title = document.querySelector("title");
    if (!title) {
      return;
    }
    const observer = new MutationObserver(() => {
      watchVideos();
      scheduleSave();
    });
    observer.observe(title, { childList: true, subtree: true, characterData: true });
  }
  function watchHistory() {
    const script = document.createElement("script");
    script.textContent = `(() => {
    const notify = () => window.postMessage({ source: 'anime-tracker', type: 'navigation' }, '*');
    const push = history.pushState;
    history.pushState = function(...args) {
      const result = push.apply(this, args);
      notify();
      return result;
    };
    const replace = history.replaceState;
    history.replaceState = function(...args) {
      const result = replace.apply(this, args);
      notify();
      return result;
    };
  })();`;
    document.documentElement.appendChild(script);
    script.remove();
    window.addEventListener("message", (event) => {
      if (event.source !== window) {
        return;
      }
      const data = event.data;
      if (isRecord(data) && data.source === "anime-tracker" && data.type === "navigation") {
        watchVideos();
        scheduleSave();
      }
    });
    window.addEventListener("popstate", () => {
      watchVideos();
      scheduleSave();
    });
  }
  function showToast(text) {
    const existing = document.getElementById("anime-tracker-toast");
    existing?.remove();
    const toast = document.createElement("div");
    toast.id = "anime-tracker-toast";
    toast.textContent = text;
    toast.style.position = "fixed";
    toast.style.right = "16px";
    toast.style.bottom = "16px";
    toast.style.zIndex = "2147483647";
    toast.style.maxWidth = "320px";
    toast.style.padding = "12px 14px";
    toast.style.borderRadius = "10px";
    toast.style.background = "#18181b";
    toast.style.color = "#fafafa";
    toast.style.font = "14px system-ui, sans-serif";
    toast.style.boxShadow = "0 8px 24px rgba(0, 0, 0, 0.35)";
    document.documentElement.appendChild(toast);
    window.setTimeout(() => {
      toast.remove();
    }, 4e3);
  }
  function isRecord(value) {
    return Boolean(value) && typeof value === "object";
  }
})();
