"use strict";
(() => {
  // src/messages.ts
  function isProgressEvent(value) {
    if (!value || typeof value !== "object") {
      return false;
    }
    const event = value;
    return typeof event.rawTitle === "string" && typeof event.episode === "number" && typeof event.siteHost === "string" && typeof event.pageUrl === "string" && typeof event.isMovie === "boolean";
  }

  // src/storage.ts
  var DEFAULT_API_BASE = "https://anitracker-zvt8.onrender.com";
  function normalizeApiBase(value) {
    const trimmed = value.trim().replace(/\/+$/, "");
    return trimmed || DEFAULT_API_BASE;
  }
  function pageOrigin(pageUrl) {
    try {
      const url = new URL(pageUrl);
      if (url.protocol !== "http:" && url.protocol !== "https:") {
        return null;
      }
      return url.origin;
    } catch {
      return null;
    }
  }
  async function loadState() {
    const stored = await chrome.storage.local.get({
      token: "",
      apiBase: DEFAULT_API_BASE,
      trackedOrigins: [],
      queue: [],
      unmatched: null
    });
    return {
      token: typeof stored.token === "string" ? stored.token : "",
      apiBase: normalizeApiBase(typeof stored.apiBase === "string" ? stored.apiBase : DEFAULT_API_BASE),
      trackedOrigins: stringList(stored.trackedOrigins),
      queue: Array.isArray(stored.queue) ? stored.queue.filter(isProgressEvent) : [],
      unmatched: isUnmatched(stored.unmatched) ? stored.unmatched : null
    };
  }
  function stringList(value) {
    if (!Array.isArray(value)) {
      return [];
    }
    return value.filter((item) => typeof item === "string");
  }
  function isUnmatched(value) {
    if (!value || typeof value !== "object") {
      return false;
    }
    const prompt = value;
    return isProgressEvent(prompt.event) && Array.isArray(prompt.candidates);
  }

  // src/popup/popup.ts
  var apiBaseInput = document.querySelector("#api-base");
  var tokenInput = document.querySelector("#token");
  var statusNode = document.querySelector("#status");
  var summaryNode = document.querySelector("#page-summary");
  var episodeInput = document.querySelector("#episode");
  var matchSection = document.querySelector("#match-section");
  var candidatesNode = document.querySelector("#candidates");
  var pageEvent = null;
  void init();
  document.querySelector("#save-settings")?.addEventListener("click", () => {
    void saveSettings();
  });
  document.querySelector("#track-site")?.addEventListener("click", () => {
    void trackThisSite();
  });
  document.querySelector("#mark")?.addEventListener("click", () => {
    void markCurrent();
  });
  document.querySelector("#plus")?.addEventListener("click", () => {
    void markNext();
  });
  async function init() {
    const state = await loadState();
    if (apiBaseInput) {
      apiBaseInput.value = state.apiBase;
    }
    if (tokenInput) {
      tokenInput.value = state.token;
    }
    renderUnmatched(state.unmatched);
    await readPage();
  }
  async function saveSettings() {
    const token = tokenInput?.value.trim() ?? "";
    const apiBase = normalizeApiBase(apiBaseInput?.value ?? "");
    const origin = pageOrigin(apiBase);
    if (!origin) {
      setStatus("API base must be an http or https URL.");
      return;
    }
    const granted = await chrome.permissions.request({ origins: [`${origin}/*`] });
    if (!granted) {
      setStatus("API permission was not granted.");
      return;
    }
    await chrome.storage.local.set({ token, apiBase });
    if (apiBaseInput) {
      apiBaseInput.value = apiBase;
    }
    setStatus(token ? "Token saved in this browser." : "Token cleared.");
  }
  async function trackThisSite() {
    const tab = await activeTab();
    if (!tab?.id || !tab.url) {
      setStatus("No active tab to track.");
      return;
    }
    const origin = pageOrigin(tab.url);
    if (!origin) {
      setStatus("This page cannot be tracked.");
      return;
    }
    const granted = await chrome.permissions.request({ origins: [`${origin}/*`] });
    if (!granted) {
      setStatus("Site permission was not granted.");
      return;
    }
    const state = await loadState();
    const trackedOrigins = state.trackedOrigins.includes(origin) ? state.trackedOrigins : [...state.trackedOrigins, origin];
    await chrome.storage.local.set({ trackedOrigins });
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    setStatus(`Tracking ${origin}`);
    await readPage();
  }
  async function readPage() {
    const tab = await activeTab();
    if (!tab?.id) {
      return;
    }
    try {
      const response = await chrome.tabs.sendMessage(tab.id, { type: "read-page" });
      const event = readEvent(response);
      pageEvent = event;
      if (!event) {
        if (summaryNode) {
          summaryNode.textContent = "No episode found yet. Enter a number, or track this site first.";
        }
        return;
      }
      if (episodeInput && !episodeInput.value) {
        episodeInput.value = String(event.episode);
      }
      if (summaryNode) {
        summaryNode.textContent = event.isMovie ? event.rawTitle : `${event.rawTitle} \xB7 episode ${event.episode}`;
      }
    } catch {
      if (summaryNode) {
        summaryNode.textContent = "Track this site to read the episode from the page.";
      }
    }
  }
  async function markCurrent() {
    const event = eventFromForm(pageEvent?.episode ?? null);
    if (!event) {
      setStatus("Enter an episode number first.");
      return;
    }
    await sendProgress(event);
  }
  async function markNext() {
    const current = Number.parseInt(episodeInput?.value ?? "", 10);
    const base = Number.isFinite(current) && current >= 1 ? current : pageEvent?.episode ?? 0;
    const next = base + 1;
    if (episodeInput) {
      episodeInput.value = String(next);
    }
    const event = eventFromForm(next);
    if (!event) {
      setStatus("Enter an episode number first.");
      return;
    }
    await sendProgress(event);
  }
  function eventFromForm(fallbackEpisode) {
    if (!pageEvent) {
      return null;
    }
    const parsed = Number.parseInt(episodeInput?.value ?? "", 10);
    const chosen = Number.isFinite(parsed) && parsed >= 1 ? parsed : fallbackEpisode;
    if (chosen === null || chosen < 1) {
      return null;
    }
    return { ...pageEvent, episode: chosen, isMovie: pageEvent.isMovie && chosen === 1 };
  }
  async function sendProgress(event) {
    const response = await chrome.runtime.sendMessage({ type: "save-progress", event });
    showSaveResult(response);
    if (response.ok && !response.matched) {
      renderUnmatched({ event, candidates: response.candidates });
    }
    if (response.ok && response.matched) {
      renderUnmatched(null);
    }
  }
  function showSaveResult(response) {
    if (response.ok && response.matched) {
      setStatus(`${response.label} \u2714`);
      return;
    }
    if (response.ok && !response.matched) {
      setStatus("Pick the matching anime below.");
      return;
    }
    if (!response.ok && response.queued) {
      setStatus("Offline. This episode is queued and will retry.");
      return;
    }
    setStatus(response.error);
  }
  function renderUnmatched(prompt) {
    if (!matchSection || !candidatesNode) {
      return;
    }
    candidatesNode.replaceChildren();
    if (!prompt || prompt.candidates.length === 0) {
      matchSection.hidden = true;
      return;
    }
    matchSection.hidden = false;
    for (const candidate of prompt.candidates) {
      const button = document.createElement("button");
      button.type = "button";
      button.className = "candidate";
      button.textContent = candidate.title_english || candidate.title_romaji;
      button.addEventListener("click", () => {
        void chooseCandidate(candidate);
      });
      candidatesNode.append(button);
    }
  }
  async function chooseCandidate(candidate) {
    const response = await chrome.runtime.sendMessage({
      type: "confirm-match",
      anilistId: candidate.anilist_id
    });
    showSaveResult(response);
    if (response.ok && response.matched) {
      renderUnmatched(null);
    }
  }
  async function activeTab() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    return tab;
  }
  function readEvent(response) {
    if (!response || typeof response !== "object" || !("event" in response)) {
      return null;
    }
    const event = response.event;
    if (!event || typeof event !== "object") {
      return null;
    }
    const page = event;
    if (typeof page.rawTitle !== "string" || typeof page.episode !== "number" || typeof page.siteHost !== "string") {
      return null;
    }
    return page;
  }
  function setStatus(text) {
    if (statusNode) {
      statusNode.textContent = text;
    }
  }
})();
