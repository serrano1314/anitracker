// src/api.ts
var ExtensionApiError = class extends Error {
  status;
  constructor(message, status) {
    super(message);
    this.name = "ExtensionApiError";
    this.status = status;
  }
};
function shouldQueue(status) {
  return status === 0 || status === 429 || status >= 500;
}
async function postProgress(apiBase, token, event) {
  const payload = await request(apiBase, token, "/api/v1/extension/progress", {
    raw_title: event.rawTitle,
    episode: event.episode,
    site_host: event.siteHost,
    page_url: event.pageUrl,
    is_movie: event.isMovie
  });
  return readProgress(payload);
}
async function postMatch(apiBase, token, event, anilistId) {
  await request(apiBase, token, "/api/v1/extension/match", {
    site_host: event.siteHost,
    raw_title: event.rawTitle,
    anilist_id: anilistId
  });
}
async function request(apiBase, token, path, body) {
  let response;
  try {
    response = await fetch(`${apiBase}${path}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`
      },
      body: JSON.stringify(body)
    });
  } catch {
    throw new ExtensionApiError("API unreachable", 0);
  }
  if (!response.ok) {
    throw new ExtensionApiError(await errorMessage(response), response.status);
  }
  return response.json();
}
async function errorMessage(response) {
  const data = await response.json().catch(() => null);
  if (data && typeof data === "object" && "detail" in data && typeof data.detail === "string") {
    return data.detail;
  }
  return response.statusText || "Request failed";
}
function readProgress(payload) {
  if (!payload || typeof payload !== "object" || !("matched" in payload)) {
    throw new ExtensionApiError("Unexpected progress response", 502);
  }
  if (payload.matched === true && "anime" in payload && "episode" in payload && isCandidate(payload.anime)) {
    return {
      matched: true,
      anime: payload.anime,
      episode: typeof payload.episode === "number" ? payload.episode : 0
    };
  }
  const candidates = "candidates" in payload && Array.isArray(payload.candidates) ? payload.candidates.filter(isCandidate) : [];
  return { matched: false, candidates };
}
function isCandidate(value) {
  if (!value || typeof value !== "object") {
    return false;
  }
  const anime = value;
  return typeof anime.anilist_id === "number" && typeof anime.title_romaji === "string";
}

// src/messages.ts
function isProgressEvent(value) {
  if (!value || typeof value !== "object") {
    return false;
  }
  const event = value;
  return typeof event.rawTitle === "string" && typeof event.episode === "number" && typeof event.siteHost === "string" && typeof event.pageUrl === "string" && typeof event.isMovie === "boolean";
}

// src/queue.ts
var QUEUE_LIMIT = 50;
function progressKey(event) {
  return `${event.siteHost}|${event.rawTitle}|${event.episode}|${event.isMovie}`;
}
function enqueueProgress(queue, event) {
  if (queue.some((item) => progressKey(item) === progressKey(event))) {
    return queue;
  }
  const next = [...queue, event];
  return next.length > QUEUE_LIMIT ? next.slice(next.length - QUEUE_LIMIT) : next;
}
function removeProgress(queue, event) {
  const key = progressKey(event);
  return queue.filter((item) => progressKey(item) !== key);
}

// src/storage.ts
var DEFAULT_API_BASE = "https://anitracker-zvt8.onrender.com";
function normalizeApiBase(value) {
  const trimmed = value.trim().replace(/\/+$/, "");
  return trimmed || DEFAULT_API_BASE;
}
function pageOrigin(pageUrl) {
  try {
    const url = new URL(pageUrl);
    if (url.protocol !== "http:" && url.protocol !== "https:") {
      return null;
    }
    return url.origin;
  } catch {
    return null;
  }
}
async function loadState() {
  const stored = await chrome.storage.local.get({
    token: "",
    apiBase: DEFAULT_API_BASE,
    trackedOrigins: [],
    queue: [],
    unmatched: null
  });
  return {
    token: typeof stored.token === "string" ? stored.token : "",
    apiBase: normalizeApiBase(typeof stored.apiBase === "string" ? stored.apiBase : DEFAULT_API_BASE),
    trackedOrigins: stringList(stored.trackedOrigins),
    queue: Array.isArray(stored.queue) ? stored.queue.filter(isProgressEvent) : [],
    unmatched: isUnmatched(stored.unmatched) ? stored.unmatched : null
  };
}
function stringList(value) {
  if (!Array.isArray(value)) {
    return [];
  }
  return value.filter((item) => typeof item === "string");
}
function isUnmatched(value) {
  if (!value || typeof value !== "object") {
    return false;
  }
  const prompt = value;
  return isProgressEvent(prompt.event) && Array.isArray(prompt.candidates);
}

// src/background.ts
chrome.runtime.onInstalled.addListener(() => {
  void chrome.alarms.create("retry-queue", { periodInMinutes: 1 });
  void flushQueue();
});
chrome.runtime.onStartup.addListener(() => {
  void flushQueue();
});
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "retry-queue") {
    void flushQueue();
  }
});
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status !== "complete" || !tab.url) {
    return;
  }
  void injectIfTracked(tabId, tab.url);
});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (isSaveMessage(message)) {
    void handleSave(message.event, sender.tab?.id).then(sendResponse);
    return true;
  }
  if (isConfirmMessage(message)) {
    void confirmMatch(message.anilistId, sender.tab?.id).then(sendResponse);
    return true;
  }
  return void 0;
});
async function handleSave(event, tabId) {
  const toastTab = tabId ?? await activeTabId();
  const state = await loadState();
  if (!state.token) {
    return { ok: false, queued: false, error: "Paste an extension token first." };
  }
  try {
    const result = await postProgress(state.apiBase, state.token, event);
    if (result.matched) {
      await chrome.storage.local.set({ unmatched: null });
      const title = result.anime.title_english || result.anime.title_romaji;
      const label = `${title} \u2014 Episode ${result.episode} saved`;
      await showToast(toastTab, `${label} \u2714`);
      return { ok: true, matched: true, label };
    }
    await chrome.storage.local.set({ unmatched: { event, candidates: result.candidates } });
    await showToast(toastTab, "No library match. Open the extension to choose the anime.");
    return { ok: true, matched: false, candidates: result.candidates };
  } catch (error) {
    if (error instanceof ExtensionApiError && !shouldQueue(error.status)) {
      return { ok: false, queued: false, error: error.message };
    }
    await chrome.storage.local.set({ queue: enqueueProgress(state.queue, event) });
    await showToast(toastTab, "Saved offline. Will retry when the API is back.");
    return { ok: false, queued: true };
  }
}
async function confirmMatch(anilistId, tabId) {
  const state = await loadState();
  if (!state.token || !state.unmatched) {
    return { ok: false, queued: false, error: "Nothing to match." };
  }
  try {
    await postMatch(state.apiBase, state.token, state.unmatched.event, anilistId);
  } catch (error) {
    const message = error instanceof ExtensionApiError ? error.message : "Could not save the match.";
    if (error instanceof ExtensionApiError && shouldQueue(error.status)) {
      return { ok: false, queued: false, error: "API unreachable. Try the match again." };
    }
    return { ok: false, queued: false, error: message };
  }
  return handleSave(state.unmatched.event, tabId);
}
async function flushQueue() {
  const state = await loadState();
  if (!state.token || state.queue.length === 0) {
    return;
  }
  let queue = state.queue;
  for (const event of [...queue]) {
    try {
      const result = await postProgress(state.apiBase, state.token, event);
      queue = removeProgress(queue, event);
      if (result.matched) {
        const title = result.anime.title_english || result.anime.title_romaji;
        await showToast(await activeTabId(), `${title} \u2014 Episode ${result.episode} saved \u2714`);
      } else {
        await chrome.storage.local.set({ unmatched: { event, candidates: result.candidates } });
      }
    } catch (error) {
      if (error instanceof ExtensionApiError && error.status === 422) {
        queue = removeProgress(queue, event);
        continue;
      }
      break;
    }
  }
  await chrome.storage.local.set({ queue });
}
async function injectIfTracked(tabId, pageUrl) {
  const origin = pageOrigin(pageUrl);
  if (!origin) {
    return;
  }
  const state = await loadState();
  if (!state.trackedOrigins.includes(origin)) {
    return;
  }
  const granted = await chrome.permissions.contains({ origins: [`${origin}/*`] });
  if (!granted) {
    return;
  }
  await chrome.scripting.executeScript({
    target: { tabId },
    files: ["content.js"]
  });
}
async function activeTabId() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab?.id;
}
async function showToast(tabId, text) {
  if (tabId === void 0) {
    return;
  }
  try {
    await chrome.tabs.sendMessage(tabId, { type: "show-toast", text });
  } catch {
  }
}
function isSaveMessage(value) {
  return Boolean(
    value && typeof value === "object" && value.type === "save-progress" && isProgressEvent(value.event)
  );
}
function isConfirmMessage(value) {
  return Boolean(
    value && typeof value === "object" && value.type === "confirm-match" && typeof value.anilistId === "number"
  );
}
